import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frutas',
  templateUrl: './frutas.page.html',
  styleUrls: ['./frutas.page.scss'],
})
export class FrutasPage implements OnInit {
 numbers:number[] = [];
 frutas:string[] = ['laranja', 'maça', 'banana', 'cereja'];

 pessoas = [
{ nome :'Carlos Alberto', idade:'50', pai: 'Abner', mae: 'Alessandra' },
{ nome :'Geovane Alves', idade: '18', pai: 'Pedro', mae: 'Ana' },
{ nome :'Francisco Silva', idade: ' 5', pai: 'Rodrigo', mae: 'Maria'},
{ nome :'Maicon Ribeiro', idade: '23', pai: 'Marcos', mae: 'Nicole'}
 ];

 times = [
  { nome :'Palmeiras', cidade:'Laranjeiras do Sul', tecnico:'Antonio'},
  { nome :'Vasco', cidade:'Rio Bonito', tecnico:'Abner'},
  { nome :'Flamengo', cidade:'Porto Barreiro', tecnico:'Chico'}
 ];





  constructor() {
    console.log("Uma frase"); 

    for (let i = 50;i>= 0; i--) {
      console.log("o número é "+i+"\n");
      this.numbers.push(i);
    }
  }

  ngOnInit() {
  }


}
