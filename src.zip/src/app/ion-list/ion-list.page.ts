import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ion-list',
  templateUrl: './ion-list.page.html',
  styleUrls: ['./ion-list.page.scss'],
})
export class IonListPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
