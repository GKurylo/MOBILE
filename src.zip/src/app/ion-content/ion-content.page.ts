import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ion-content',
  templateUrl: './ion-content.page.html',
  styleUrls: ['./ion-content.page.scss'],
})
export class IonContentPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
