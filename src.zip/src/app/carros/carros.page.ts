import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carros',
  templateUrl: './carros.page.html',
  styleUrls: ['./carros.page.scss'],
})
export class CarrosPage implements OnInit {

listagens = [
{
  'imagem' : "https://www.pastorecc.com.br/site/photos/cars/70/md_9419168852d913c173deb.JPG", 
  'subtitulo' : "O melhor carro do mundo",
  'titulo' : "Opala Comodoro 74",
  'descricao' : "O dono tem que ser socio do posto"
},

{
  'imagem' : "https://motortudo.com/wp-content/uploads/2018/06/Volkswagen-Fusca-1300-1974-Motor-Tudo-2.jpeg",
  'subtitulo' : "Tanque de guerra",
  'titulo' : "Fusca",
  'descricao' : "Pode causar uma guerra"
},

{
  'imagem' : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTumopzstk9lmcAaa-2TCJdE74CjPr1Ya4N7A&s",
  'subtitulo' : "Uma piscina",
  'titulo' : "Chevette",
  'descricao' : "Entra agua ate sem chuva"
},

{
  'imagem' : "https://cdn.motor1.com/images/mgl/ojooqp/s3/ford-maverick-fx4-na-pista-de-tatui.jpg",
  'subtitulo' : "Como virou isso?",
  'titulo' : "Maverick",
  'descricao' : "Oque levou a cometerem esse crime?"
},

{
  'imagem' : "https://i.pinimg.com/originals/c9/13/61/c9136167ad431cad64dfc5597a7a4db6.jpg",
  'subtitulo' : "(Com escada)",
  'titulo' : "Uno ",
  'descricao' : "Não se conhece a velocidade final"
},

];











  constructor() { }

  ngOnInit() {
  }

}
