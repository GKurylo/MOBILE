import { Component } from '@angular/core';

@Component({
  selector: 'app-tab1',
  templateUrl: 'tab1.page.html',
  styleUrls: ['tab1.page.scss']
})
export class Tab1Page {

constructor() {}




txtNome = '';

txtSenha = '';

txtEmail = '';

txtTelefone= '';

txtIdade:number = 0;
permissaoDirigir = false;


// dentro do parenteses de chama: condição
virificarSePodeDirigir(){
  if (this.txtIdade >=18) {
 this.permissaoDirigir = true;
  }else{
 this.permissaoDirigir = false;
  }

}


  

}
