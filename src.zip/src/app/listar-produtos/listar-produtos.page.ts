import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-listar-produtos',
  templateUrl: './listar-produtos.page.html',
  styleUrls: ['./listar-produtos.page.scss'],
})
export class ListarProdutosPage implements OnInit {

produtos = [
  {
    'nome' : 'Chevette',
    'imagem' : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTumopzstk9lmcAaa-2TCJdE74CjPr1Ya4N7A&s",
    'valor' : 'R$5.000,00'
  },

  {
    'nome' : 'Pão de Manteiga',
    'imagem' : "https://kimpaes.com.br/wp-content/uploads/2019/09/pao_de_forma_tradicional_1000x1000.png",
    'valor' : 'R$2,50'
  },

  {
    'nome' : 'Dinossauro de brinquedo',
    'imagem' : "https://http2.mlstatic.com/D_NQ_NP_807772-MLU72649871827_112023-O.webp",
    'valor' : 'R$149,90'
  },

  {
    'nome' : 'Abacate',
    'imagem' : 'https://phygital-files.mercafacil.com/greenfruit/uploads/produto/abacate_in_natura_kg_3277372a-b862-4371-b10a-dcc1b30747c0.png',
    'valor' : 'R$8,99'
  },

  {
    'nome' : 'Fox 40',
    'imagem' : 'https://www.dirtmerchantbicycles.com/cdn/shop/products/40-factory-grip2-orange-1_1024x1024.jpg?v=1636515022',
    'valor' : 'R$5,50'
  },

  {
    'nome' : 'Bala',
    'imagem' : 'https://docemalu.vtexassets.com/arquivos/ids/5344485-800-auto?v=638421837841230000&width=800&height=auto&aspect=true',
    'valor' : 'R$100,00'
  },

  {
    'nome' : 'Notboock Gamer',
    'imagem' : 'https://i.zst.com.br/thumbs/12/20/30/-793297929.jpg',
    'valor' : 'R$6.700,00'
  },

  {
    'nome' : 'Tijolo 6 furos',
    'imagem' : 'https://cdn.leroymerlin.com.br/products/tijolo_a_vista_6_furos_9x14x24cm_ceramica_porto_galera_89088923_5090_600x600.jpg',
    'valor' : 'R$10,00'
  },
]




  constructor() { }

  ngOnInit() {
  }

}
