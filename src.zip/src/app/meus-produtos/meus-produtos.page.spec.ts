import { ComponentFixture, TestBed } from '@angular/core/testing';
import { MeusProdutosPage } from './meus-produtos.page';

describe('MeusProdutosPage', () => {
  let component: MeusProdutosPage;
  let fixture: ComponentFixture<MeusProdutosPage>;

  beforeEach(() => {
    fixture = TestBed.createComponent(MeusProdutosPage);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
