import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-meus-produtos',
  templateUrl: './meus-produtos.page.html',
  styleUrls: ['./meus-produtos.page.scss'],
})
export class MeusProdutosPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

  produtos = [
  { nome: 'Coca Cola', codigo: '123456789', estoque: '40', imagem: 'https://pizzabraga.com/wp-content/uploads/product_images/product_colaLata-80.jpg'},
  { nome: 'Chocolate', codigo: '321654987', estoque: '9', imagem: 'https://compremais.vtexassets.com/unsafe/fit-in/720x720/center/middle/https%3A%2F%2Fcompremais.vtexassets.com%2Farquivos%2Fids%2F408906%2FBarra-de-Chocolate-ao-Leite-Lacta-Pacote165g.jpg%3Fv%3D638549503558900000'},
  { nome: 'Feijão', codigo: '456987231', estoque: '14', imagem: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR155PQuSjyrOyMKHntIKgADj-O9yyVqJEjiA&s'},
  { nome: 'Arroz', codigo: '565478982', estoque: '21', imagem: 'https://www.rampinelli.com.br/uploads/produto/arroz-branco-1698345336.png?class=full-img&w=406&h=583&fit=contain'},
  { nome: 'Banana', codigo: '963214785', estoque: '34', imagem: 'https://mercadoorganico.com/6398-large_default/banana-prata-organica-600g-osm.jpg'},
  { nome: 'Melancia', codigo: '147852369', estoque: '7', imagem: 'https://scfoods.fbitsstatic.net/img/p/melancia-mini-unidade-70680/257182.jpg?w=800&h=800&v=no-change&qs=ignore'}
  ];

}

